from scrapy import Spider
from amazon.items import AmazonItem
import scrapy

class AmazonSpider(Spider):
    name = "amazon"
    allow_domain = ['www.amazon.in']
    start_urls = [
        'https://www.amazon.in/s?k=sumsunf&rh=n%3A1389401031&ref=nb_sb_noss'
    ]
    handle_httpstatus_list = [503]

    def parse(self,response):
        if response.status == 503:
            yield scrapy.FormRequest(url = response.url,callback = self.parse,dont_filter=True)
        else:
            dh=response.text
            print(dh)
            product = response.xpath('//*[@data-component-type="s-search-results"]/div/div')

            n = response.xpath('//span[@class="a-size-medium a-color-base a-text-normal"]').get()
            print("==================Name==============",n)
            p = response.xpath('.//span[@class="a-offscreen"]/text()').get()
            print("===================Price============",p)
            img = response.xpath('//div[@class="a-section aok-relative s-image-fixed-height"]/img/@src').get()
            print("======================Image=======================",img) 
            r = response.xpath('.//i[@class="a-icon a-icon-star-small a-star-small-4-5 aok-align-bottom"]/span[@class="a-icon-alt"]').get()
            print("==================Rating==============",r)
            for p in product:
                item = AmazonItem()
                item['name'] = p.xpath('.//span[@class="a-size-base-plus a-color-base a-text-normal"]//text()').get()
                item['price'] = p.xpath('.//span[@class="a-offscreen"]/text()').get()
                item['image'] = p.xpath('.//img/@src').get()
                item['rating'] = p.xpath('.//i[@class="a-icon a-icon-star-small a-star-small-4-5 aok-align-bottom"]/span[@class="a-icon-alt"]/text()').get()

                yield item

            nextpage = response.xpath('//li[@class="a-last"]/a/@href').get(default='')
            if nextpage:
                g ='https://www.amazon.in'+nextpage
                yield scrapy.Request(url=g,callback=self.parse)

from scrapy.cmdline import execute
execute('scrapy crawl amazon'.split())